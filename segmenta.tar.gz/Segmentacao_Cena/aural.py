import feature_manipulator as fm
from python_speech_features import mfcc
from moviepy.video.io.VideoFileClip import VideoFileClip

def extractMfcc(videoPath, shots, stream=0):
    video = VideoFileClip(videoPath)
    audio = video.audio
    fps = video.fps

    featuresPerShot = []

    for i in range(shots.shape[0]):
        # np.ceil desconsiderada por induzir exceção em tomadas de curta duração
        # inicio = np.ceil(shots.iloc[i,0] / fps)
        # fim = np.ceil(shots.iloc[i,1] / fps)
        inicio = shots.iloc[i, 0] / fps
        fim = shots.iloc[i, 1] / fps

        audioShot = audio.subclip(inicio, fim).to_soundarray()
        if len(audioShot.shape) > 1:
            audioShot = audioShot[:,stream]
        # nfft is the greatest power of 2 closest to samplerate*winlen
        featuresPerShot.append(mfcc(audioShot, samplerate=44100, winlen=0.030, winstep=0.020, nfft=2048))

    audio.close()
    video.close()

    return featuresPerShot

if __name__ == '__main__':
    import pandas as pd
    import pickle
    import sys

    if len(sys.argv) != 5:
        print('USE python aural.py shots.file video.file dictionary_size stream')
        sys.exit(0)

    shots = pd.read_csv(sys.argv[1])
    shots -= 1
    # print(shots)

    dictSize = int(sys.argv[3])
    stream = int(sys.argv[4])

    auralFeaturesPerShot = extractMfcc(sys.argv[2], shots, stream)
    auralLabels, auralCentroids = fm.getBagOfFeatures(auralFeaturesPerShot, dictSize)
    auralHistogram = fm.getHistogram(auralFeaturesPerShot, auralLabels, dictSize)
    normalizedAuralHistogram = fm.normalizeHistogram(auralHistogram)
    # print(auralFeaturesPerShot)

    with open('aural_histogram', 'wb') as arq:
        pickle.dump(normalizedAuralHistogram, arq)

    print("Extração aural concluída")