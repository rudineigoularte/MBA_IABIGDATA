import cv2 as cv
import numpy as np
import pandas as pd
import pickle
import sys

SIMILARITY_THRESHOLD = 0.95
MIN_SIMILARITY = 0.2

def compareHistograms(histogram1, histogram2):
    return cv.compareHist(histogram1, histogram2, cv.HISTCMP_INTERSECT)

def getHistogram(frame):
    hsv_frame = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
    histogram = cv.calcHist([hsv_frame], [0,1,2], None, [8,4,4], [0,180,0,256,0,256])
    histogram /= np.sum(histogram)
    return histogram

def extractHistograms(videoPath, shots):
    histogramsPerShot = [[] for n in range(shots.shape[0])]
    nShot = 0
    frameNumber = 0
    isProcessingShot = True

    video = cv.VideoCapture(videoPath)
    while video.isOpened():
        success, frame = video.read()

        if not success:
            break

        if frameNumber <= shots['end'][nShot] and isProcessingShot:
            histogramsPerShot[nShot].append(getHistogram(frame))
            pass
        else:
            if isProcessingShot:
                nShot += 1
            if frameNumber < shots['begin'][nShot]:
                isProcessingShot = False
            else:
                histogramsPerShot[nShot].append(getHistogram(frame))
                isProcessingShot = True

        frameNumber += 1
    video.release()

    return histogramsPerShot

def extractKeyFrames(histograms):
    nHistograms = len(histograms)
    similar = np.zeros(nHistograms, dtype='int')

    for i in range(nHistograms):
        for j in range(i+1, nHistograms):
            if compareHistograms(histograms[i], histograms[j]) >= SIMILARITY_THRESHOLD:
                similar[i] += 1
                similar[j] += 1

    keyframes = []

    while True:
        maxIndex = similar.argmax()
        maxValue = similar[maxIndex]

        if maxValue < nHistograms * MIN_SIMILARITY and len(keyframes) > 0:
            break

        candidate = histograms[maxIndex]
        similar[maxIndex] = 0

        isCandidateDissimilar = True
        for kf in keyframes:
            if compareHistograms(candidate, histograms[kf]) >= SIMILARITY_THRESHOLD:
                isCandidateDissimilar = False
                break

        if isCandidateDissimilar:
            keyframes.append(maxIndex)

    return keyframes

if len(sys.argv) != 3:
    print('USE python keyframe_extractor.py videoShotSegmentation.csv video.mp4')
    sys.exit(0)

# Quadros inicial e final por tomada
shots = pd.read_csv(sys.argv[1])
# Se o primeiro frame começar por um, normalize os índices
if shots.iloc[0,0] == 1:
    shots -= 1


# Histogramas dos quadros agrupados por tomada
histogramsPerShot = extractHistograms(sys.argv[2], shots)

# Keyframes por tomada
keyframesPerShot = []
for histograms in histogramsPerShot:
    keyframesPerShot.append(extractKeyFrames(histograms))

# Normalização do número do keyframe em relação ao quadro inicial da tomada
for i in range(shots.shape[0]):
    keyframesPerShot[i] += shots['begin'][i]

filename = sys.argv[2][:len(sys.argv[2]) - 4] + '_keyframes'
with open(filename, 'wb') as arq:
    pickle.dump(keyframesPerShot, arq)