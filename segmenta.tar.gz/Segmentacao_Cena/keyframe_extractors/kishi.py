import cv2 as cv
import numpy as np
import pandas as pd
import pickle
import sys

THRESHOLD = 0.6

def compareHistograms(histogram1, histogram2):
    return cv.compareHist(histogram1, histogram2, cv.HISTCMP_INTERSECT)

def getHistogram(frame):
    # [0,1,2] refers to processed channels (B, G and R, in this case)
    # None uses the whole image instead of a ROI
    # [4,4,4] refers to number of bins for each channel
    # [0,256,0,256,0,256] refers to the intervals in which varies each channel value
    histogram = cv.calcHist([frame], [0,1,2], None, [4,4,4], [0,256,0,256,0,256])
    histogram /= np.sum(histogram)
    return histogram

def extractHistograms(videoPath, shots):
    histogramsPerShot = [[] for n in range(shots.shape[0])]
    nShot = 0
    frameNumber = 0
    isProcessingShot = True

    video = cv.VideoCapture(videoPath)
    while video.isOpened():
        success, frame = video.read()

        if not success:
            break

        if frameNumber <= shots['end'][nShot] and isProcessingShot:
            histogramsPerShot[nShot].append(getHistogram(frame))
        else:
            if isProcessingShot:
                nShot += 1
            if frameNumber < shots['begin'][nShot]:
                isProcessingShot = False
            else:
                histogramsPerShot[nShot].append(getHistogram(frame))
                isProcessingShot = True

        frameNumber += 1
    video.release()

    return histogramsPerShot

def extractKeyframes(histograms, threshold=THRESHOLD):
    keyframes = []
    nHistograms = len(histograms)
    frames = [i for i in range(nHistograms)]

    distanceMatrix = np.zeros((nHistograms, nHistograms))
    for i in range(nHistograms):
        for j in range(i+1, nHistograms):
            distanceMatrix[i,j] = distanceMatrix[j,i] = 1 - compareHistograms(histograms[i], histograms[j])
    meanDistances = np.mean(distanceMatrix, axis=1)
    firstKeyframe = meanDistances.argmin()
    keyframes.append(firstKeyframe)
    frames.pop(firstKeyframe)

    while len(frames) != 0:
        meanDistances = np.zeros(len(frames))

        for i in range(len(frames)):
            for keyframe in keyframes:
                meanDistances[i] += distanceMatrix[keyframe, frames[i]]
            meanDistances[i] /= len(keyframes)
    
        index = meanDistances.argmax()
        if meanDistances[index] >= threshold:
            mostDistantFrame = frames[index]
            keyframes.append(mostDistantFrame)
            frames.pop(index)
        else:
            break
    
    return keyframes

if len(sys.argv) != 3:
    print('USE python kishi.py videoShotSegmentation.csv video.mp4')
    sys.exit(0)

# Quadros inicial e final por tomada
shots = pd.read_csv(sys.argv[1])
# Se o primeiro frame começar por um, normalize os índices
if shots.iloc[0,0] == 1:
    shots -= 1

# Histogramas dos quadros agrupados por tomada
histogramsPerShot = extractHistograms(sys.argv[2], shots)

# Keyframes por tomada
keyframesPerShot = []
for histograms in histogramsPerShot:
    keyframesPerShot.append(sorted(extractKeyframes(histograms)))

# Normalização do número do keyframe em relação ao quadro inicial da tomada
for i in range(shots.shape[0]):
    keyframesPerShot[i] += shots['begin'][i]

filename = sys.argv[2][:len(sys.argv[2]) - 4] + '_keyframes'
with open(filename, 'wb') as arq:
    pickle.dump(keyframesPerShot, arq)

print("Extração de keyframes concluída")