import networkx as nx
import numpy as np
from scipy.spatial import distance

class STG:

    def __init__(self, multiModalHistogram, delta=0.35, timeThreshold=7):
        self.delta = delta
        self.timeThreshold = timeThreshold

        nShots = len(multiModalHistogram)

        self.interShotDistances = np.zeros((nShots, nShots))
        for i in range(nShots):
            for j in range(i+1, nShots):
                self.interShotDistances[i][j] = self.interShotDistances[j][i] = distance.cosine(multiModalHistogram[i], multiModalHistogram[j])

    def clusterDistance(self, clusterA, clusterB):
        maxDist = 0
        for shotI in clusterA:
            for shotJ in clusterB:
                if self.interShotDistances[shotI][shotJ] > maxDist:
                    if abs(shotI - shotJ) > self.timeThreshold:
                        maxDist = float('inf')
                    else:
                        maxDist = self.interShotDistances[shotI][shotJ]
            
        return maxDist

    def allClustersDistancesGreaterThanDelta(self):
        nClusters = len(self.clusters)
        for i in range(nClusters):
            for j in range(i+1, nClusters):
                if self.clusterDistance(self.clusters[i], self.clusters[j]) <= delta:
                    return False
        return True

    def linkageCluster(self):
        nClusters = len(self.interShotDistances)
        self.clusters = [[i] for i in range(nClusters)]

        while not self.allClustersDistancesGreaterThanDelta() and nClusters > 1:
            minDist = self.interShotDistances[0][1]
            clusterR = 0
            clusterS = 1
            for i in range(nClusters):
                for j in range(i+1, nClusters):
                    currentDist = self.clusterDistance(self.clusters[i], self.clusters[j])
                    if currentDist < minDist:
                        minDist = currentDist
                        clusterR = i
                        clusterS = j

            # Merge R and S into a new cluster
            for shot in self.clusters[clusterS]:
                self.clusters[clusterR].append(shot)
            self.clusters.pop(clusterS)
            nClusters -= 1
    
    def containsSubsequentShots(self, clusterA, clusterB):
        for shotI in clusterA:
            for shotJ in clusterB:
                if shotI == shotJ + 1 or shotJ == shotI + 1:
                    return True

        return False        

    def buildGraph(self):
        # STG Construction
        nClusters = len(self.clusters)
        self.g = nx.Graph()
        for i in range(nClusters):
            self.g.add_node(i)

        for i in range(nClusters):
            for j in range(i+1, nClusters):
                if self.containsSubsequentShots(self.clusters[i], self.clusters[j]):
                    self.g.add_edge(i, j)

        bridges = nx.bridges(self.g)
        for bridge in bridges:
            self.g.remove_edge(bridge[0], bridge[1])

    def segment(self):
        connectedComponents = list(nx.connected_components(self.g))
        nConnectedComponents = len(connectedComponents)
        for i in range(nConnectedComponents):
            for node in connectedComponents[i]:
                self.g.nodes[node]['scene'] = i

        # Divide shots into scenes
        scenes = [[] for i in range(nConnectedComponents)]
        for node in self.g.nodes.data():
            scenes[node[1]['scene']].append(node[0])

        self.scenesBoundaries = np.empty((nConnectedComponents, 2), dtype=np.int32)
        for i in range(nConnectedComponents):
            shotsInScene = []
            for clusterIndex in scenes[i]:
                shotsInScene += self.clusters[clusterIndex]
            shotsInScene = sorted(shotsInScene)
            self.scenesBoundaries[i][0] = shotsInScene[0] + 1
            self.scenesBoundaries[i][1] = shotsInScene.pop() + 1

if __name__ == '__main__':
    import pickle
    import sys

    nParameters = len(sys.argv)
    if nParameters < 2 or nParameters > 4:
        print('USE python STG.py shotHistograms [delta] [timeThresold]')
        sys.exit(1)
    elif nParameters > 2:
        delta = float(sys.argv[2])
        if nParameters > 3:
            timeThreshold = int(sys.argv[3])
        else:
            timeThreshold = 7
    else:
        delta = 0.35
        timeThreshold = 7

    with open(sys.argv[1], 'rb') as arq:
        multiModalHistograms = pickle.load(arq)

    stg = STG(multiModalHistograms, delta, timeThreshold)
    stg.linkageCluster()
    stg.buildGraph()
    stg.segment()

    startIndex = sys.argv[1].find('multi')
    filename = sys.argv[1][:startIndex] + 'scene_segmentation' + sys.argv[1][startIndex + 20:]
    with open(filename,'wb') as arq:
        pickle.dump(stg.scenesBoundaries, arq)

    print("Segmentação concluída")