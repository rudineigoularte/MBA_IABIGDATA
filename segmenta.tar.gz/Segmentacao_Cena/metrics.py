import pandas as pd
import pickle
import sys

def getPrecisionAndRecall(gt, seg, shotTolerance):
    '''
    gt and seg are sets of tuples containing the first and last shot of every scene in, respectively,
    the ground truth annotation and segmentation algorithm output
    '''
    gt = set(boundary[-1] for boundary in gt)
    seg = set(boundary[-1] for boundary in seg)
    gtWithTolerance = gt.copy()
    for boundary in gt:
        for i in range(boundary - shotTolerance, boundary + shotTolerance + 1):
            if i>=1: gtWithTolerance.add(i)

    vp = len(gtWithTolerance.intersection(seg))
    fp = len(seg.difference(gt))
    fn = len(gt.difference(seg))

    precision = vp / (vp + fp)
    recall = vp / (vp + fn)
    f1 = 2 * precision * recall / (precision + recall)

    return precision, recall, f1

def getNewOverflow(gt, seg):
    newOverflowForScene = []
    for boundaryGt in gt:
        soma = 0
        for boundarySeg in seg:
            if boundarySeg[0] > boundaryGt[-1]:
                break
            intersection = len(set.intersection(set(boundaryGt), set(boundarySeg)))
            if intersection > 0:
                soma += len(boundarySeg)
        no = 0
        if soma != 0:
            subtraendo = len(boundaryGt) / soma
            # Only for debug purposes
            if subtraendo > 1:
                print('NEGATIVE NEW OVERFLOW')
            no = 1 - subtraendo
        newOverflowForScene.append(no)
    
    nShots = gt[-1][-1]

    avgNewOverflow = 0
    for i in range(len(gt)):
        avgNewOverflow += (newOverflowForScene[i] * len(gt[i]) / nShots)

    return avgNewOverflow


def getCoverage(gt, seg):
    '''
    gt and seg are sets containing the first and the last shot of every scene in, respectively,
    the ground truth annotation and segmentation algorithm output
    '''
    coverageForScene = []
    for boundaryGt in gt:
        maior = 0
        for boundarySeg in seg:
            if boundarySeg[0] > boundaryGt[-1]:
                break
            maior = max(maior, len(set.intersection(set(boundaryGt), set(boundarySeg))))
        coverageForScene.append(maior / len(boundaryGt))

    nShots = gt[-1][-1]

    avgCoverage = 0
    for i in range(len(gt)):
        avgCoverage += (coverageForScene[i] * len(gt[i])/nShots)

    return avgCoverage

def toSet(input):
    output = []
    for i in input:
        output.append(range(i[0], i[1]+1))
    return output

if len(sys.argv) != 4:
    print('USE python metrics.py sceneSegmentation.file groundTruthScenes.file shot_tolerance')
    sys.exit(0)

with open(sys.argv[1], 'rb') as arq:
    scenesBoundaries = pickle.load(arq)
predictedBoundaries = toSet(scenesBoundaries)

# ler groundTruth de arquivo
scenes = pd.read_csv(sys.argv[2])
groundTruth = list((boundary[0], boundary[1]) for _,boundary in scenes.iterrows())
groundTruth = toSet(groundTruth)

shotTolerance = int(sys.argv[3])

# p,r,fpr = getPrecisionAndRecall(groundTruth, predictedBoundaries, shotTolerance)
# print('precision é', p)
# print('recall é', r)
# print('Fpr é', fpr)

c = getCoverage(groundTruth, predictedBoundaries)
no = getNewOverflow(groundTruth, predictedBoundaries)
fcno = 2 * (c * (1 - no)) / (c + 1 - no)
print('coverage é', c)
print('1 - new overflow é', 1 - no)
print('Fcno é', fcno)