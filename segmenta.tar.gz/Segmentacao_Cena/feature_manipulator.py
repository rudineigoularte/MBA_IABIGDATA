import cv2 as cv
import numpy as np

def getBagOfFeatures(featuresPerShot, n):
    data = []
    for features in featuresPerShot:
        for feature in features:
            if feature is not None:
                if len(feature.shape) == 2:
                    for feat in feature:
                        data.append(feat)
                else:
                    data.append(feature)
    data = np.asarray(data, dtype=np.float32)
    criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 100, 1.0)
    ret,labels,centroids = cv.kmeans(data, n, None, criteria, 10, cv.KMEANS_PP_CENTERS)
    return labels, centroids

def getClosestCentroid(keypoint, centroids):
    dist = np.empty(len(centroids), dtype='float')

    for i in range(len(centroids)):
        dist[i] = np.linalg.norm(centroids[i] - keypoint)

    return dist.argmin()

def getHistogram(featuresPerShot, labels, dictSize):
    nShots = len(featuresPerShot)
    i = 0
    histogram = np.zeros((nShots, dictSize), dtype=np.float32)
    for shotIndex in range(nShots):
        for feature in featuresPerShot[shotIndex]:
            if feature is not None:
                if len(feature.shape) == 2:
                    for feat in feature:
                        histogram[shotIndex][labels[i][0]] += 1
                        i += 1
                else:
                    histogram[shotIndex][labels[i][0]] += 1
                    i += 1
    return histogram

def normalizeHistogram(histogram):
    normalizedHistogram = histogram / histogram.sum(axis=1).reshape(-1,1)
    np.nan_to_num(normalizedHistogram, copy=False)
    return normalizedHistogram
