import math
import numpy as np
from scipy.signal import find_peaks
from scipy.spatial import distance

class SHS:

    def gaussianKernel(self, histogram, value):
        kernel = 1 / math.sqrt(2 * math.pi * self.sigma) * math.exp(-value * value / (2 * self.sigma * self.sigma))
        newHistogram = histogram * kernel
        return newHistogram

    def gaussianSmooth(self, shotIndex):
        smoothedHistogram = np.zeros(self.multiModalHistograms[0].shape)
        for i in range(self.multiModalHistograms.shape[0]):
            smoothedHistogram += self.gaussianKernel(self.multiModalHistograms[i], shotIndex - i)
        return smoothedHistogram

    def __init__(self, multiModalHistograms, sigma = 8):
        self.multiModalHistograms = multiModalHistograms
        self.sigma = sigma

        # Build the smoothed histograms
        self.smoothedHistograms = np.empty(multiModalHistograms.shape)
        for i in range(len(multiModalHistograms)):
            self.smoothedHistograms[i] = self.gaussianSmooth(i)

        # Intershot distances
        self.interShotDistances = np.zeros(multiModalHistograms.shape[0] - 1)
        for i in range(multiModalHistograms.shape[0] - 1):
            self.interShotDistances[i] = distance.euclidean(self.smoothedHistograms[i], self.smoothedHistograms[i+1])
    
    def segment(self):
        shotTransitionIndexes = find_peaks(self.interShotDistances)[0] + 1

        self.scenesBoundaries = np.empty((shotTransitionIndexes.shape[0] + 1, 2), dtype=np.int32)
        self.scenesBoundaries[0] = (1, shotTransitionIndexes[0])

        for i in range(1, shotTransitionIndexes.shape[0]):
            self.scenesBoundaries[i] = (self.scenesBoundaries[i-1][1] + 1, shotTransitionIndexes[i])

        self.scenesBoundaries[i+1] = (self.scenesBoundaries[i][1] + 1, self.multiModalHistograms.shape[0])

        return self.scenesBoundaries

if __name__ == '__main__':
    import pickle
    import sys

    nParameters = len(sys.argv)
    if nParameters < 2 or nParameters > 3:
        print('USE python STG.py shotHistograms [sigma]')
        sys.exit(1)
    elif nParameters == 3:
        sigma = int(sys.argv[2])
    else:
        sigma = 8

    with open(sys.argv[1], 'rb') as arq:
        multiModalHistograms = pickle.load(arq)

    shs = SHS(multiModalHistograms, sigma)
    shs.segment()

    filename = 'shs_segmentation_with_sigma=' + str(sigma)
    with open(filename,'wb') as arq:
        pickle.dump(shs.scenesBoundaries, arq)