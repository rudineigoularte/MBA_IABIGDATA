# Operador M4INFUS
import cv2 as cv
import numpy as np

class M4InFus:

    @staticmethod
    def maxPooling(group, weight=1):
        tomadas = len(group[0])
        maxPools = np.empty(tomadas)
        for tomada in range(tomadas):
            maxPool = float('-inf')
            for i in range(len(group)):
                if group[i][tomada] > maxPool:
                    maxPool = group[i][tomada]
            maxPools[tomada] = maxPool * weight if len(group) > 1 else maxPool
        return maxPools

    @staticmethod
    def avgPooling(group, weight=1):
        tomadas = len(group[0])
        avgPools = np.empty(tomadas)
        for tomada in range(tomadas):
            sum = 0.0
            for i in range(len(group)):
                sum += group[i][tomada]
            avgPool = sum / len(group)
            avgPools[tomada] = avgPool * weight if len(group) > 1 else avgPool
        return avgPools

    def __init__(self, histograms, dictSize, pooling):
        for i in range(len(histograms)):
            histograms[i] = histograms[i].T
        self.multiModalHistogram = np.concatenate(histograms)
        self.dictionarySize = dictSize
        self.pooling = pooling

    def merge(self):
        criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 100, 1.0)
        ret,labels,centers = cv.kmeans(self.multiModalHistogram, self.dictionarySize, None, criteria, 10, cv.KMEANS_PP_CENTERS)

        groups = [[] for i in range(self.dictionarySize)]
        # for i in range(len(labels)):
        #     groups[labels[i][0]].append(self.multiModalHistogram[i])
        rotulos = labels.reshape(-1)
        for i in range(self.dictionarySize):
            groups[i] = self.multiModalHistogram[rotulos == i]
        

        correlationDescriptors = np.empty((self.dictionarySize, groups[0][0].shape[0]))
        for groupIndex in range(self.dictionarySize):
            if self.pooling == 'max':
                correlationDescriptors[groupIndex] = M4InFus.maxPooling(groups[groupIndex])
            elif self.pooling == 'avg':
                correlationDescriptors[groupIndex] = M4InFus.avgPooling(groups[groupIndex])
            elif self.pooling == 'max_w':
                correlationDescriptors[groupIndex] = M4InFus.maxPooling(groups[groupIndex], weight=2)
            else:
                print('Pooling must be one of these [max, avg, max_w, avg_w]')
                return None

        return correlationDescriptors.T

class Soma:

    def __init__(self, histograms):
        self.histograms = histograms

    def merge(self):
        multiModalHistogram = np.zeros(self.histograms[0].shape)
        for histogram in self.histograms:
            multiModalHistogram += histogram

        multiModalHistogram /= multiModalHistogram.sum(axis=1).reshape(-1,1)
        np.nan_to_num(multiModalHistogram, copy=False)

        return multiModalHistogram

class Concatenation:

    def __init__(self, histograms):
        self.histograms = histograms

    def merge(self):
        multiModalHistogram = self.histograms[0]
        for histogram in self.histograms[1:]:
            multiModalHistogram = np.concatenate((multiModalHistogram, histogram), axis=1)

        multiModalHistogram /= multiModalHistogram.sum(axis=1).reshape(-1,1)
        np.nan_to_num(multiModalHistogram, copy=False)

        return multiModalHistogram

class Gram:

    def __init__(self, histograms):
        self.histograms = histograms

    def merge(self):
        nShots = self.histograms[0].shape[0]
        nModalities = len(self.histograms)
        multiModalHistogram = np.empty((nShots, nModalities * (nModalities+1) // 2), dtype=np.float32)

        for i in range(nShots):
            fusionSpace = np.vstack([histogram[i] for histogram in self.histograms])
            gramMatrix = fusionSpace @ fusionSpace.T
            gramFeature = gramMatrix[0]
            for j in range(1, nModalities):
                gramFeature = np.concatenate((gramFeature, gramMatrix[j][j:]))
            multiModalHistogram[i] = gramFeature

        multiModalHistogram /= multiModalHistogram.sum(axis=1).reshape(-1,1)
        np.nan_to_num(multiModalHistogram, copy=False)

        return multiModalHistogram

if __name__ == '__main__':
    import pickle
    import sys

    if len(sys.argv) < 2:
        print('USE python fusion_operators.py [m4infus,soma,gram,concatenation] [pooling] [dictSize]')
        sys.exit(1)

    with open('visual_histogram', 'rb') as arq:
        visualHistogram = pickle.load(arq)

    with open('aural_histogram', 'rb') as arq:
        auralHistogram = pickle.load(arq)

    operator = sys.argv[1]
    if operator == 'm4infus':
        if len(sys.argv) != 4:
            print('USE python fusion_operators.py m4infus pooling dictSize')
            sys.exit(1)
        pooling = sys.argv[2]
        dictSize = int(sys.argv[3])
        fusionOperator = M4InFus([visualHistogram, auralHistogram], dictSize, pooling)
    elif operator == 'soma':
        fusionOperator = Soma([visualHistogram, auralHistogram])
    elif operator == 'gram':
        fusionOperator = Gram([visualHistogram, auralHistogram])
    elif operator == 'concatenation':
        fusionOperator = Concatenation([visualHistogram, auralHistogram])
    else:
        print('''Operator must be one of these [m4infus,soma,gram,concatenation]''')
        sys.exit(1)

    multiModalHistogram = fusionOperator.merge()

    filename = 'multimodal_histogram_' + operator
    with open(filename, 'wb') as arq:
        pickle.dump(multiModalHistogram, arq)
    
    print("Fusão de modalidades concluída")