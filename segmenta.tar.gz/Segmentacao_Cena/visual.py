# Script para extrair histograma visual
import cv2 as cv
import feature_manipulator as fm
import numpy as np

def featureExtractor(frame, method='sift'):
    if method == 'sift': return __sift(frame)
    elif method == 'surf': return __surf(frame)

def __surf(frame):
    gray_frame = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    surf = cv.xfeatures2d.SURF_create(extended=True)
    kp, des = surf.detectAndCompute(gray_frame, None)
    return des

def __sift(frame):
    gray_frame = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    sift = cv.xfeatures2d.SIFT_create()
    kp, des = sift.detectAndCompute(gray_frame, None)
    # if des is None:
    #     des = np.full((1,128), 127, dtype=np.float32)
    return des

def extractFeatures(videoPath, keyframesPerShot, method='sift'):
    video = cv.VideoCapture(videoPath)

    nShots = len(keyframesPerShot)
    featuresPerShot = [[] for n in range(nShots)]

    for shotIndex in range(nShots):
        for keyframe in keyframesPerShot[shotIndex]:
            video.set(cv.CAP_PROP_POS_FRAMES, keyframe)
            success, frame = video.read()
            featuresPerShot[shotIndex].append(featureExtractor(frame, method=method))
        # if featuresPerShot[shotIndex][0] is None:
        #     featuresPerShot[shotIndex] = [np.full((1,128), 127, dtype=np.float32)]

    video.release()

    return featuresPerShot

if __name__ == '__main__':
    import pandas as pd
    import pickle
    import sys

    if len(sys.argv) != 4:
        print("USE python visual.py keyframes.file video.file dictionary_size")
        sys.exit(0)

    with open(sys.argv[1], 'rb') as arq:
        keyframesPerShot = pickle.load(arq)
    # print(keyframes)

    dictSize = int(sys.argv[3])

    visualFeaturesPerShot = extractFeatures(sys.argv[2], keyframesPerShot)
    # print(visualFeatures)
    visualLabels, visualCentroids = fm.getBagOfFeatures(visualFeaturesPerShot, dictSize)
    # print(visualLabels)
    # [shot][centroid]
    histogram = fm.getHistogram(visualFeaturesPerShot, visualLabels, dictSize)
    # print(visualFeaturesfeaturesPerShot

    normalizedVisualHistogram = fm.normalizeHistogram(histogram)

    with open('visual_histogram', 'wb') as arq:
        pickle.dump(normalizedVisualHistogram, arq)

    # print(normVisualFeatures)